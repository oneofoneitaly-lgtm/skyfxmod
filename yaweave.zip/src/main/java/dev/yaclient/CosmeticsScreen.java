package dev.yaclient;

import dev.yaclient.cosmetics.CosmeticPreview;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Cosmetics locker in the white YA MODS style (bundles, capes, wings, bandanas, pets, partner). */
public class CosmeticsScreen extends GuiScreen {

    private static final String[] CATS = {"bundle", "cape", "wings", "bandana", "pet", "partner"};
    private static final int[] BCOL = {0xFFE10600, 0xFFB8B8C0, 0xFF7CC4F8, 0xFFFF86B6, 0xFF8C6CFF, 0xFFFF9B3D, 0xFFFF4040, 0xFF6EC6FF, 0xFFFFD21F, 0xFF3DDC6A};

    private int cat;
    private float scroll, scrollTarget;
    private int px, py, pw, ph, gx, gy, gw, gh;
    private long openTime;
    private final List<Object[]> hits = new ArrayList<Object[]>();   // {x, y, w, h, Runnable}
    private int gridContent;

    @Override
    public void initGui() {
        openTime = System.currentTimeMillis();
        CosmeticsApi.refreshAsync(false);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void hit(int x, int y, int w, int h, Runnable r) {
        hits.add(new Object[]{x, y, w, h, r});
    }

    private String lt(String key, String def) {
        try {
            return Lang.has(key) ? Lang.t(key) : def;
        } catch (Throwable t) {
            return def;
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        hits.clear();
        FontRenderer fr = fontRendererObj;
        float o = Math.min(1.0F, (System.currentTimeMillis() - openTime) / 200.0F);
        o = 1.0F - (1.0F - o) * (1.0F - o);
        drawRect(0, 0, width, height, ((int) (o * 110.0F) << 24));
        pw = Math.min(width - 16, 450);
        ph = Math.min(height - 16, 276);
        px = (width - pw) / 2;
        py = (height - ph) / 2 + (int) ((1.0F - o) * 10.0F);
        YaUi.roundBox(px, py, px + pw, py + ph, 6, YaUi.BORDER, YaUi.BG, 1);

        // header
        YaUi.roundRect(px + 1, py + 1, px + pw - 1, py + 30, 5, YaUi.HEADER);
        drawRect(px + 1, py + 20, px + pw - 1, py + 30, YaUi.HEADER);
        drawRect(px + 1, py + 30, px + pw - 1, py + 31, YaUi.LINE);
        fr.drawString("COSMETICS", px + 12, py + 11, YaUi.DARK);
        String esc = "ESC";
        fr.drawString(esc, px + pw - 12 - fr.getStringWidth(esc), py + 11, YaUi.SOFT);
        if (CosmeticsApi.enabled()) {
            String s = lt("cos.store", "Store");
            int sw = fr.getStringWidth(s) + 20;
            int bx = px + pw - 12 - fr.getStringWidth(esc) - 12 - sw;
            boolean hv = in(mx, my, bx, py + 6, sw, 18);
            YaUi.roundRect(bx, py + 6, bx + sw, py + 24, 4, hv ? YaUi.DARK : YaUi.ACCENT);
            fr.drawString(s, bx + 10, py + 11, 0xFFFFFFFF);
            hit(bx, py + 6, sw, 18, new Runnable() { public void run() { CosmeticsApi.openStore(); } });
        }

        // loadout preview (left)
        int lw = 116, lx = px + 10, ly = py + 40, lh = ph - 50;
        YaUi.roundBox(lx, ly, lx + lw, ly + lh, 5, YaUi.BORDER, YaUi.CARD, 1);
        String lo = lt("cos.loadout", "Loadout");
        fr.drawString(lo, lx + (lw - fr.getStringWidth(lo)) / 2, ly + 8, YaUi.MID);
        boolean plusOn = CosmeticsApi.plus();
        String pl = lt(plusOn ? "cos.plus.on" : "cos.plus.off", plusOn ? "PLUS" : "FREE");
        int plw = fr.getStringWidth(pl) + 14;
        YaUi.roundRect(lx + (lw - plw) / 2, ly + 22, lx + (lw + plw) / 2, ly + 36, 4, plusOn ? YaUi.ACCENT : YaUi.CHIP);
        fr.drawString(pl, lx + (lw - plw) / 2 + 7, ly + 26, plusOn ? 0xFFFFFFFF : YaUi.MID);
        YaUi.scissor(mc, lx + 1, ly + 38, lx + lw - 1, ly + lh - 1);
        if (mc.thePlayer != null) drawPlayer(lx + lw / 2, ly + lh - 14, 64, (System.currentTimeMillis() % 11000L) / 11000f * 360f, null);
        GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
        YaUi.scissorOff();

        // category pills
        int x0 = lx + lw + 10, wRight = px + pw - 10 - x0;
        int cx = x0;
        for (int i = 0; i < CATS.length; i++) {
            final int idx = i;
            String lab = lt("cos.cat." + CATS[i], CATS[i]);
            int w = fr.getStringWidth(lab) + 16;
            boolean on = cat == i, hv = in(mx, my, cx, py + 40, w, 18);
            YaUi.roundBox(cx, py + 40, cx + w, py + 58, 4, on ? YaUi.ACCENT : YaUi.BORDER, on ? YaUi.ACCENT : (hv ? YaUi.CARD_HOVER : YaUi.CARD), 1);
            fr.drawString(lab, cx + 8, py + 45, on ? 0xFFFFFFFF : YaUi.MID);
            hit(cx, py + 40, w, 18, new Runnable() { public void run() { cat = idx; scroll = 0; scrollTarget = 0; } });
            cx += w + 5;
        }

        // grid
        List<String> entries = new ArrayList<String>();
        boolean partnerTab = CATS[cat].equals("partner");
        for (int bi = 0; bi < Cosmetics.BUNDLES.length; bi++) {
            if (partnerTab) { if (Cosmetics.isPartner(bi)) entries.add("bundle:" + bi); continue; }
            if (Cosmetics.isPartner(bi)) continue;
            entries.add((cat == 0 ? "bundle" : CATS[cat]) + ":" + bi);
        }
        if (!partnerTab && cat > 0) {
            String suffix = "_" + CATS[cat];
            for (String ex : Cosmetics.EXTRAS) if (ex.endsWith(suffix)) entries.add("x:" + CATS[cat] + ":" + ex);
        }
        gx = x0;
        gy = py + 64;
        gw = wRight;
        gh = ly + lh - 24 - gy;
        int gap = 8, cols = gw >= 300 ? 3 : 2, cw = (gw - gap * (cols - 1)) / cols, ch = 132;
        int rows = (entries.size() + cols - 1) / cols;
        gridContent = Math.max(0, rows * (ch + gap) - gap);
        scrollTarget = Math.max(0, Math.min(scrollTarget, gridContent - gh));
        scroll += (scrollTarget - scroll) * 0.35F;
        int gs = Math.round(scroll);
        YaUi.scissor(mc, gx - 1, gy, gx + gw + 1, gy + gh);
        for (int n = 0; n < entries.size(); n++) {
            final String[] kv = entries.get(n).split(":");
            final boolean single = kv[0].equals("x");
            final String key = single ? kv[1] : kv[0];
            final int bi = single ? 0 : Integer.parseInt(kv[1]);
            int cardX = gx + (n % cols) * (cw + gap), cardY = gy - gs + (n / cols) * (ch + gap);
            if (cardY + ch < gy || cardY > gy + gh) continue;
            final boolean bundle = !single && key.equals("bundle");
            final String id = single ? kv[2] : (bundle ? Cosmetics.BUNDLES[bi] : Cosmetics.item(bi, key));
            boolean has, on;
            if (bundle) {
                has = Cosmetics.ownsBundle(bi);
                on = has && Cosmetics.wearsBundle(bi);
            } else {
                has = CosmeticsApi.owned(id);
                on = has && Cosmetics.selected(key).equals(id);
            }
            boolean hv = in(mx, my, cardX, cardY, cw, ch) && my >= gy && my < gy + gh;
            YaUi.roundBox(cardX, cardY, cardX + cw, cardY + ch, 5, on ? YaUi.ACCENT : (hv ? YaUi.MID : YaUi.BORDER), hv ? YaUi.CARD_HOVER : YaUi.CARD, 1);
            int th = 86, tx = cardX + 5, ty = cardY + 5;
            int tint = single ? 0xFFB8B8C8 : BCOL[bi];
            YaUi.roundRect(tx, ty, tx + cw - 10, ty + th, 4, YaUi.lerp(0xFFFFFFFF, tint, 0.20F));
            // thumbnail: the player wearing the item (clipped to the thumbnail and the grid)
            int sy0 = Math.max(ty, gy), sy1 = Math.min(ty + th, gy + gh);
            if (sy1 > sy0) {
                YaUi.scissor(mc, tx, sy0, tx + cw - 10, sy1);
                if (mc.thePlayer != null) {
                    drawWornCard(key, bi, bundle, single ? id : null, cardX + cw / 2, ty + th - 6, 40);
                } else {
                    float ps = key.equals("cape") ? 40f : key.equals("wings") ? 24f : key.equals("bandana") || key.equals("pet") ? 64f : 22f;
                    CosmeticPreview.draw(key, single ? id.substring(0, id.lastIndexOf('_')) : Cosmetics.PREFIX[bi], cardX + cw / 2f, ty + th / 2f + 2f, ps, System.currentTimeMillis(), CosmeticsApi.plus());
                }
                GL11.glClear(GL11.GL_DEPTH_BUFFER_BIT);
                YaUi.scissor(mc, gx - 1, gy, gx + gw + 1, gy + gh);
            }
            // tag
            if (bundle) {
                String tag = Cosmetics.isPartner(bi) ? lt("cos.partner_tag", "PARTNER") + " " + Cosmetics.PARTNER_NAME[bi] : lt(bi == 0 ? "cos.free" : "cos.exclusive", bi == 0 ? "FREE" : "EXCLUSIVE");
                int tw = fr.getStringWidth(tag) + 10;
                YaUi.roundRect(tx + 4, ty + 4, tx + 4 + tw, ty + 16, 4, bi == 0 ? YaUi.ACCENT : 0xFFFFFFFF);
                fr.drawString(tag, tx + 9, ty + 6, bi == 0 ? 0xFFFFFFFF : YaUi.DARK);
            }
            if (!has) fr.drawString("✕", tx + cw - 10 - 11, ty + 5, YaUi.SOFT);
            String name = lt(bundle ? "cos.bundle." + id : "cos.item." + id, id);
            name = fr.trimStringToWidth(name, cw - 12);
            fr.drawString(name, cardX + 6, cardY + th + 11, YaUi.DARK);
            String st = on ? lt("cos.equipped", "Equipped") : (has ? lt("cos.click_equip", "Click to equip") : lt(CosmeticsApi.premium() ? "cos.get" : "cos.premium_only", "Get"));
            fr.drawString(fr.trimStringToWidth(st, cw - 12), cardX + 6, cardY + ch - 14, on ? YaUi.DARK : YaUi.SOFT);
            final boolean fHas = has;
            int hy0 = Math.max(cardY, gy), hy1 = Math.min(cardY + ch, gy + gh);
            if (hy1 > hy0) hit(cardX, hy0, cw, hy1 - hy0, new Runnable() {
                public void run() {
                    if (!fHas) {
                        if (!CosmeticsApi.premium()) return;
                        if (bundle) CosmeticsApi.openBundle(Cosmetics.BUNDLES[bi]); else CosmeticsApi.openItem(id);
                        return;
                    }
                    if (bundle) Cosmetics.toggleBundle(bi); else if (single) Cosmetics.toggleItem(key, id); else Cosmetics.toggle(bi, key);
                }
            });
        }
        YaUi.scissorOff();
        if (entries.isEmpty()) fr.drawString(lt("cos.partner_hint", "Nothing here yet"), gx + 4, gy + 6, YaUi.SOFT);

        // footer: sync status
        String stKey;
        if (!CosmeticsApi.enabled()) stKey = "cos.dev_mode";
        else if (CosmeticsApi.status().isEmpty()) stKey = "cos.syncing";
        else stKey = "cos.status." + CosmeticsApi.status();
        String foot = lt(stKey, "") + (CosmeticsApi.enabled() && !CosmeticsApi.detail().isEmpty() ? " [" + CosmeticsApi.detail() + "]" : "");
        fr.drawString(fr.trimStringToWidth(foot, wRight), x0, ly + lh - 14, YaUi.SOFT);
    }

    // ----- player preview (same render layer as in game) -----
    private void drawWornCard(String key, int bi, boolean bundle, String single, int cx, int baseY, int size) {
        Map<String, String> ov = new HashMap<String, String>();
        for (String sl : Cosmetics.SLOTS) ov.put(sl, "none");
        if (single != null) ov.put(key, single);
        else if (bundle) { for (String sl : Cosmetics.SLOTS) ov.put(sl, Cosmetics.item(bi, sl)); }
        else ov.put(key, Cosmetics.item(bi, key));
        ov.put("plus", CosmeticsApi.plus() ? "1" : "0");
        boolean front = key.equals("bandana") || key.equals("pet");
        float base = front ? 335f : 150f;
        float sway = (float) Math.sin(System.currentTimeMillis() / 1100.0) * 14f;
        drawPlayer(cx, baseY, size, base + sway, ov);
    }

    private void drawPlayer(int cx, int baseY, int size, float spin, Map<String, String> override) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer ent = mc.thePlayer;
        if (ent == null) return;
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.disableBlend();
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.enableAlpha();
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) cx, (float) baseY, 50.0F);
        GlStateManager.scale((float) (-size), (float) size, (float) size);
        GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
        float ro = ent.renderYawOffset, pro = ent.prevRenderYawOffset, ry = ent.rotationYaw, pry = ent.prevRotationYaw,
                rp = ent.rotationPitch, prh = ent.prevRotationYawHead, rh = ent.rotationYawHead;
        GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
        ent.renderYawOffset = spin; ent.prevRenderYawOffset = spin;
        ent.rotationYaw = spin; ent.prevRotationYaw = spin;
        ent.rotationYawHead = spin; ent.prevRotationYawHead = spin;
        ent.rotationPitch = 0f;
        RenderManager rm = mc.getRenderManager();
        rm.setPlayerViewY(180.0F);
        rm.setRenderShadow(false);
        CosmeticsApi.previewOverride = override;
        try { rm.renderEntityWithPosYaw(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F); } finally { CosmeticsApi.previewOverride = null; }
        rm.setRenderShadow(true);
        ent.renderYawOffset = ro; ent.prevRenderYawOffset = pro;
        ent.rotationYaw = ry; ent.prevRotationYaw = pry;
        ent.rotationPitch = rp; ent.prevRotationYawHead = prh; ent.rotationYawHead = rh;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) {
        super.mouseClicked(mx, my, button);
        if (button != 0) return;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Object[] h = hits.get(i);
            if (in(mx, my, (Integer) h[0], (Integer) h[1], (Integer) h[2], (Integer) h[3])) {
                ((Runnable) h[4]).run();
                return;
            }
        }
    }

    @Override
    public void handleMouseInput() {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) scrollTarget = Math.max(0, Math.min(gridContent - gh, scrollTarget - Integer.signum(d) * 36));
    }

    @Override
    protected void keyTyped(char c, int key) {
        if (key == Keyboard.KEY_ESCAPE || key == Keyboard.KEY_RSHIFT) mc.displayGuiScreen(null);
    }
}
