package dev.yaclient;

import dev.yaclient.modules.HudModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.List;

/**
 * HUD editor: drag elements anywhere, resize with the corner handle or the mouse wheel, snap to
 * the screen center and edges. Positions are saved when you leave the editor.
 */
public class HudEditorScreen extends GuiScreen {
    private static final int HANDLE = 8, SNAP = 4;

    private HudModule selected, dragging, resizing;
    private float grabX, grabY;
    private int gs = 2;
    private float guideX = -1, guideY = -1;
    private int btnResetX, btnDoneX, btnY, btnW = 70, btnH = 22;

    private float sx(HudModule m) { return m.screenX(width); }
    private float sy(HudModule m) { return m.screenY(height); }
    private float sw(HudModule m) { return m.width() * m.screenScale(); }
    private float sh(HudModule m) { return m.height() * m.screenScale(); }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        gs = new ScaledResolution(Minecraft.getMinecraft()).getScaleFactor();
        Gui.drawRect(0, 0, width, height, 0x22000000);

        List<HudModule> list = Hud.elements();
        for (HudModule m : list) m.renderHud(true, width, height, gs);

        net.minecraft.client.gui.FontRenderer fr = fontRendererObj;

        // guides
        if (guideX >= 0) Gui.drawRect(Math.round(guideX), 0, Math.round(guideX) + 1, height, 0xCCFFFFFF);
        if (guideY >= 0) Gui.drawRect(0, Math.round(guideY), width, Math.round(guideY) + 1, 0xCCFFFFFF);

        for (HudModule m : list) {
            int x = Math.round(sx(m)), y = Math.round(sy(m));
            int w = Math.max(6, Math.round(sw(m))), h = Math.max(6, Math.round(sh(m)));
            boolean over = mx >= x && mx < x + w && my >= y && my < y + h;
            boolean hot = m == selected || m == dragging || m == resizing || over;
            int c = hot ? 0xFFFFFFFF : 0x90FFFFFF;
            int x1 = x - 2, y1 = y - 2, x2 = x + w + 2, y2 = y + h + 2;
            Gui.drawRect(x1, y1, x2, y1 + 1, c);
            Gui.drawRect(x1, y2 - 1, x2, y2, c);
            Gui.drawRect(x1, y1, x1 + 1, y2, c);
            Gui.drawRect(x2 - 1, y1, x2, y2, c);
            if (m == selected) YaUi.roundRect(x + w - HANDLE + 2, y + h - HANDLE + 2, x + w + 2, y + h + 2, 3, 0xFFFFFFFF);
            if (hot) {
                String nm = m.name();
                int tw0 = fr.getStringWidth(nm) + 10;
                int ty0 = y1 - 14 < 2 ? y2 + 3 : y1 - 14;
                YaUi.roundRect(x1, ty0, x1 + tw0, ty0 + 12, 4, YaUi.ACCENT);
                fr.drawString(nm, x1 + 5, ty0 + 2, 0xFFFFFFFF);
            }
        }

        // header panel (YA MODS look)
        String t1 = "HUD editor";
        String t2 = "Drag the modules to move them  -  mouse wheel to resize  -  ESC to go back";
        btnW = 44; btnH = 16;
        int pw0 = Math.max(fr.getStringWidth(t2), fr.getStringWidth(t1) * 2) + 24 + 2 * btnW + 14;
        pw0 = Math.min(pw0, width - 12);
        int x0 = (width - pw0) / 2;
        YaUi.roundRect(x0, 8, x0 + pw0, 40, 6, YaUi.BG);
        fr.drawString(t1, x0 + 12, 13, YaUi.DARK);
        fr.drawString(fr.trimStringToWidth(t2, pw0 - 24 - 2 * btnW - 14), x0 + 12, 26, YaUi.MID);
        btnY = 13;
        btnDoneX = x0 + pw0 - btnW - 8;
        btnResetX = btnDoneX - btnW - 4;
        button("Reset", btnResetX, mx, my, false);
        button("Done", btnDoneX, mx, my, true);

        if (list.isEmpty()) {
            String e = Lang.t("editor.empty");
            fr.drawString(e, (width - fr.getStringWidth(e)) / 2, height / 2, 0xFFFFFFFF);
        }
    }

    private void button(String label, int x, int mx, int my, boolean primary) {
        boolean over = mx >= x && mx < x + btnW && my >= btnY && my < btnY + btnH;
        int fill = primary ? (over ? 0xFF4A4A4A : YaUi.ACCENT) : (over ? 0xFFD4D4D4 : YaUi.CHIP);
        YaUi.roundRect(x, btnY, x + btnW, btnY + btnH, 6, fill);
        net.minecraft.client.gui.FontRenderer fr = fontRendererObj;
        fr.drawString(label, x + (btnW - fr.getStringWidth(label)) / 2, btnY + 4, primary ? 0xFFFFFFFF : YaUi.MID);
    }

    private void leave() {
        Hud.saveLayout();
        Minecraft.getMinecraft().displayGuiScreen(null);
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) {
        if (button != 0) return;
        if (my >= btnY && my < btnY + btnH) {
            if (mx >= btnDoneX && mx < btnDoneX + btnW) { leave(); return; }
            if (mx >= btnResetX && mx < btnResetX + btnW) { Hud.resetLayout(); selected = null; return; }
        }
        List<HudModule> list = Hud.elements();
        for (int i = list.size() - 1; i >= 0; i--) {
            HudModule m = list.get(i);
            int x = Math.round(sx(m)), y = Math.round(sy(m));
            int w = Math.max(6, Math.round(sw(m))), h = Math.max(6, Math.round(sh(m)));
            if (m == selected && mx >= x + w - HANDLE && mx <= x + w + 4 && my >= y + h - HANDLE && my <= y + h + 4) {
                resizing = m;
                return;
            }
            if (mx >= x && mx < x + w && my >= y && my < y + h) {
                selected = m;
                dragging = m;
                grabX = mx - sx(m);
                grabY = my - sy(m);
                return;
            }
        }
        selected = null;
    }

    @Override
    protected void mouseClickMove(int mx, int my, int button, long time) {
        guideX = guideY = -1;
        if (dragging != null) {
            HudModule m = dragging;
            float w = sw(m), h = sh(m);
            float x = mx - grabX, y = my - grabY;
            // snap element center / edges to the screen center and borders
            float cx = x + w / 2f, cy = y + h / 2f;
            if (Math.abs(cx - width / 2f) < SNAP) { x = width / 2f - w / 2f; guideX = width / 2f; }
            else if (Math.abs(x) < SNAP) x = 0;
            else if (Math.abs(x + w - width) < SNAP) x = width - w;
            if (Math.abs(cy - height / 2f) < SNAP) { y = height / 2f - h / 2f; guideY = height / 2f; }
            else if (Math.abs(y) < SNAP) y = 0;
            else if (Math.abs(y + h - height) < SNAP) y = height - h;
            m.px = Ui.clamp(x / width, 0f, 1f);
            m.py = Ui.clamp(y / height, 0f, 1f);
        } else if (resizing != null) {
            HudModule m = resizing;
            float base = Math.max(1, m.width()) * Hud.globalScale();
            m.scale = Ui.clamp((mx - sx(m)) / base, HudModule.MIN_SCALE, HudModule.MAX_SCALE);
        }
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        dragging = null;
        resizing = null;
        guideX = guideY = -1;
        Hud.saveLayout();
    }

    @Override
    public void handleMouseInput() {
        int d = Mouse.getEventDWheel();
        if (d != 0 && selected != null) {
            selected.scale = Ui.clamp(selected.scale + (d > 0 ? 0.05f : -0.05f), HudModule.MIN_SCALE, HudModule.MAX_SCALE);
        }
        try { super.handleMouseInput(); } catch (Exception ignored) { }
    }

    @Override
    protected void keyTyped(char typed, int key) {
        if (key == Keyboard.KEY_ESCAPE) { Hud.saveLayout(); Minecraft.getMinecraft().displayGuiScreen(new YaModMenu()); return; }
        if (key == Keyboard.KEY_RSHIFT) { leave(); return; }
        if (selected == null) return;
        float step = (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) ? 5f : 1f);
        if (key == Keyboard.KEY_LEFT) selected.px = Ui.clamp(selected.px - step / width, 0f, 1f);
        if (key == Keyboard.KEY_RIGHT) selected.px = Ui.clamp(selected.px + step / width, 0f, 1f);
        if (key == Keyboard.KEY_UP) selected.py = Ui.clamp(selected.py - step / height, 0f, 1f);
        if (key == Keyboard.KEY_DOWN) selected.py = Ui.clamp(selected.py + step / height, 0f, 1f);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
