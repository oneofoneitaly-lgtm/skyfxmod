package dev.yaclient;

import dev.yaclient.modules.Category;
import dev.yaclient.modules.Module;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** The mods menu (Right Shift, MODS): module cards with a switch and a settings page per module. YA MODS look. */
public class YaModMenu extends GuiScreen {

    private static final int GAP = 8, CARD_H = 50, ROW_H = 22, HEAD_H = 14;

    private final List<String> cats = new ArrayList<String>();
    private final List<Category> catKeys = new ArrayList<Category>();
    private Category category;          // null = All
    private String query = "";
    private boolean searching;
    private final List<Module> shown = new ArrayList<Module>();
    private final Map<Module, float[]> anim = new IdentityHashMap<Module, float[]>(); // [0] hover, [1] switch knob
    private Module open;                 // module whose settings page is shown
    private Setting.Num dragging;
    private Setting.Text editing;
    private Setting.Key keyEdit;
    private float scroll, scrollTarget, gridScroll;
    private long openTime;

    private int px, py, pw, ph, gx, gy, gw, gh, cols, cardW;

    private static final class Row {
        final String head;
        final Setting s;

        Row(String head, Setting s) { this.head = head; this.s = s; }

        int h() { return head != null ? HEAD_H : ROW_H; }
    }

    @Override
    public void initGui() {
        openTime = System.currentTimeMillis();
        cats.clear();
        catKeys.clear();
        cats.add("All");
        catKeys.add(null);
        for (Category c : Category.values()) {
            cats.add(c.label());
            catKeys.add(c);
        }
        rebuild();
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void onGuiClosed() {
        for (Module m : YAClient.MODULES) m.saveConfig();
        Config.save();
    }

    private float[] an(Module m) {
        float[] a = anim.get(m);
        if (a == null) {
            a = new float[]{0f, m.enabled ? 1f : 0f};
            anim.put(m, a);
        }
        return a;
    }

    private void rebuild() {
        shown.clear();
        for (Module m : YAClient.MODULES) {
            if (!m.available) continue;
            if (category != null && m.category != category) continue;
            if (query.length() > 0) {
                String q = query.toLowerCase();
                if (!m.name().toLowerCase().contains(q) && !m.desc().toLowerCase().contains(q)) continue;
            }
            shown.add(m);
        }
        scroll = 0.0F;
        scrollTarget = 0.0F;
    }

    private void layout() {
        pw = Math.min(460, width - 20);
        ph = Math.min(292, height - 20);
        float o = Math.min(1.0F, (System.currentTimeMillis() - openTime) / 230.0F);
        o = 1.0F - (1.0F - o) * (1.0F - o) * (1.0F - o);
        px = (width - pw) / 2;
        py = (height - ph) / 2 + (int) ((1.0F - o) * 14.0F);
        gx = px + 14;
        gy = py + 64;
        gw = pw - 28 - 8;
        gh = ph - 64 - 40;
        cols = gw >= 300 ? 2 : 1;
        cardW = (gw - GAP * (cols - 1)) / cols;
    }

    private int maxScroll() {
        int rows = (shown.size() + cols - 1) / cols;
        return Math.max(0, rows * (CARD_H + GAP) - GAP - gh);
    }

    private int cardX(int i) { return gx + (i % cols) * (cardW + GAP); }

    private int cardY(int i) { return gy + (i / cols) * (CARD_H + GAP) - (int) scroll; }

    // ------------------------------------------------------------------ draw

    @Override
    public void drawScreen(int mx, int my, float pt) {
        layout();
        FontRenderer fr = fontRendererObj;
        float o = Math.min(1.0F, (System.currentTimeMillis() - openTime) / 230.0F);

        Gui.drawRect(0, 0, width, height, ((int) (60 * o)) << 24);

        YaUi.roundRect(px + 2, py + 3, px + pw + 2, py + ph + 3, 8, 0x26000000);
        YaUi.roundRect(px, py, px + pw, py + ph, 8, YaUi.BG);
        YaUi.roundRect(px, py, px + pw, py + 36, 8, YaUi.HEADER);
        Gui.drawRect(px, py + 20, px + pw, py + 36, YaUi.HEADER);
        Gui.drawRect(px, py + 36, px + pw, py + 37, YaUi.LINE);

        GlStateManager.pushMatrix();
        GlStateManager.translate(px + 14, py + 10, 0);
        GlStateManager.scale(1.5F, 1.5F, 1.0F);
        fr.drawString("YA MODS", 0, 0, YaUi.DARK);
        GlStateManager.popMatrix();
        fr.drawString("by @Adryh01", px + 14 + (int) (fr.getStringWidth("YA MODS") * 1.5F) + 8, py + 15, YaUi.SOFT);

        int cbx = px + pw - 28, cby = py + 9;
        boolean overClose = mx >= cbx && mx < cbx + 18 && my >= cby && my < cby + 18;
        YaUi.roundRect(cbx, cby, cbx + 18, cby + 18, 4, overClose ? 0xFFD4D4D4 : YaUi.CHIP);
        fr.drawString("x", cbx + 9 - fr.getStringWidth("x") / 2, cby + 5, YaUi.MID);

        if (open == null) drawGrid(mx, my, fr);
        else drawSettings(mx, my, fr);

        // footer
        int fy = py + ph - 26;
        Gui.drawRect(px, py + ph - 34, px + pw, py + ph - 33, YaUi.LINE);
        boolean overEdit = mx >= px + 14 && mx < px + 78 && my >= fy - 1 && my < fy + 15;
        YaUi.roundRect(px + 14, fy - 1, px + 78, fy + 15, 6, overEdit ? 0xFF4A4A4A : YaUi.ACCENT);
        String edit = "Edit HUD";
        fr.drawString(edit, px + 46 - fr.getStringWidth(edit) / 2, fy + 3, 0xFFFFFFFF);
        String hint = "Right Shift to close";
        fr.drawString(hint, px + pw - 14 - fr.getStringWidth(hint), fy + 3, YaUi.SOFT);
    }

    private void drawGrid(int mx, int my, FontRenderer fr) {
        int cx = px + 14;
        for (int k = 0; k < cats.size(); k++) {
            String c = cats.get(k);
            int cw = fr.getStringWidth(c) + 16;
            boolean sel = catKeys.get(k) == category;
            boolean over = mx >= cx && mx < cx + cw && my >= py + 43 && my < py + 59;
            YaUi.roundRect(cx, py + 43, cx + cw, py + 59, 6, sel ? YaUi.ACCENT : (over ? 0xFFD8D8D8 : YaUi.CHIP));
            fr.drawString(c, cx + 8, py + 47, sel ? 0xFFFFFFFF : YaUi.MID);
            cx += cw + 6;
        }

        int sbw = Math.min(120, Math.max(0, px + pw - 14 - cx - 4)), sbx = px + pw - 14 - sbw;
        if (sbw >= 70) {
            YaUi.roundBox(sbx, py + 43, sbx + sbw, py + 59, 6, searching ? YaUi.ACCENT : YaUi.BORDER, 0xFFFFFFFF, 1);
            String shownQ = query.length() == 0 && !searching ? "Search mods..." : query;
            if (searching && (System.currentTimeMillis() / 500) % 2 == 0) shownQ += "_";
            fr.drawString(fr.trimStringToWidth(shownQ, sbw - 12, true), sbx + 6, py + 47, query.length() == 0 && !searching ? YaUi.SOFT : YaUi.DARK);
        }
        if (shown.isEmpty()) fr.drawString("No mods found.", gx + 4, gy + 6, YaUi.SOFT);

        int max = maxScroll();
        scrollTarget = Math.max(0, Math.min(max, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.35F;
        if (Math.abs(scrollTarget - scroll) < 0.2F) scroll = scrollTarget;

        YaUi.scissor(mc, gx - 2, gy, gx + gw + 2, gy + gh);
        boolean inGrid = mx >= gx && mx < gx + gw && my >= gy && my < gy + gh;
        for (int i = 0; i < shown.size(); i++) {
            Module m = shown.get(i);
            int x = cardX(i), y = cardY(i);
            if (y + CARD_H < gy || y > gy + gh) continue;
            boolean over = inGrid && mx >= x && mx < x + cardW && my >= y && my < y + CARD_H;
            float[] a = an(m);
            a[0] += ((over ? 1.0F : 0.0F) - a[0]) * 0.3F;
            a[1] += ((m.enabled ? 1.0F : 0.0F) - a[1]) * 0.35F;

            int border = m.enabled ? YaUi.ACCENT : YaUi.lerp(YaUi.BORDER, YaUi.SOFT, a[0]);
            YaUi.roundBox(x, y, x + cardW, y + CARD_H, 5, border, over ? YaUi.CARD_HOVER : YaUi.CARD, m.enabled ? 2 : 1);

            fr.drawString(fr.trimStringToWidth(m.name(), cardW - 50), x + 9, y + 8, YaUi.DARK);
            fr.drawString(fr.trimStringToWidth(m.desc(), cardW - 18), x + 9, y + 21, YaUi.MID);
            fr.drawString(m.category.label(), x + 9, y + CARD_H - 13, YaUi.SOFT);
            YaUi.sw(x + cardW - 32, y + 8, a[1]);

            if (!m.settings.isEmpty()) {
                int bx = x + cardW - 62, by = y + CARD_H - 18;
                boolean overBtn = over && mx >= bx && mx < bx + 54 && my >= by && my < by + 13;
                YaUi.roundRect(bx, by, bx + 54, by + 13, 5, overBtn ? 0xFFD4D4D4 : YaUi.CHIP);
                String t = "Settings";
                fr.drawString(t, bx + 27 - fr.getStringWidth(t) / 2, by + 3, YaUi.MID);
            }
        }
        YaUi.scissorOff();

        if (max > 0) {
            int tx = gx + gw + 4;
            Gui.drawRect(tx, gy, tx + 3, gy + gh, 0xFFE2E2E2);
            int rows = (shown.size() + cols - 1) / cols;
            int content = rows * (CARD_H + GAP) - GAP;
            int th = Math.max(18, gh * gh / content);
            int ty = gy + (int) ((gh - th) * (scroll / max));
            YaUi.roundRect(tx, ty, tx + 3, ty + th, 1, 0xFF9C9C9C);
        }
    }

    private String choiceText(Setting.Choice c) {
        String id = c.current();
        return Lang.has("opt." + id) ? Lang.t("opt." + id) : id;
    }

    private void drawSettings(int mx, int my, FontRenderer fr) {
        boolean overBack = mx >= gx && mx < gx + 52 && my >= py + 43 && my < py + 59;
        YaUi.roundRect(gx, py + 43, gx + 52, py + 59, 6, overBack ? 0xFFD8D8D8 : YaUi.CHIP);
        fr.drawString("< Back", gx + 26 - fr.getStringWidth("< Back") / 2, py + 47, YaUi.MID);

        GlStateManager.pushMatrix();
        GlStateManager.translate(gx + 62, py + 44, 0);
        GlStateManager.scale(1.25F, 1.25F, 1.0F);
        fr.drawString(open.name(), 0, 0, YaUi.DARK);
        GlStateManager.popMatrix();
        String st = open.enabled ? "Enabled" : "Disabled";
        fr.drawString(st, gx + gw - fr.getStringWidth(st) - 30, py + 47, open.enabled ? YaUi.DARK : YaUi.SOFT);
        float[] oa = an(open);
        oa[1] += ((open.enabled ? 1.0F : 0.0F) - oa[1]) * 0.35F;
        YaUi.sw(gx + gw - 24, py + 45, oa[1]);

        scrollTarget = Math.max(0, Math.min(settingsMax(), scrollTarget));
        scroll += (scrollTarget - scroll) * 0.35F;
        if (Math.abs(scrollTarget - scroll) < 0.2F) scroll = scrollTarget;
        YaUi.scissor(mc, gx - 2, gy, gx + gw + 2, gy + gh);
        int y = gy + 4 - (int) scroll;
        for (Row r : rows()) {
            if (r.head != null) {
                fr.drawString(r.head, gx + 4, y + 3, YaUi.SOFT);
                y += HEAD_H;
                continue;
            }
            Setting s = r.s;
            boolean over = mx >= gx && mx < gx + gw && my >= Math.max(y, gy) && my < Math.min(y + ROW_H, gy + gh);
            YaUi.roundRect(gx, y, gx + gw, y + ROW_H - 2, 4, over ? YaUi.CARD_HOVER : YaUi.CARD);
            fr.drawString(fr.trimStringToWidth(s.label(), gw - 170), gx + 10, y + 7, YaUi.DARK);
            int right = gx + gw - 10;
            if (s instanceof Setting.Bool) {
                YaUi.sw(right - 22, y + 4, ((Setting.Bool) s).value ? 1.0F : 0.0F);
            } else if (s instanceof Setting.Num) {
                Setting.Num n = (Setting.Num) s;
                int tx = right - 150, tw = 100;
                Gui.drawRect(tx, y + 9, tx + tw, y + 12, 0xFFD0D0D0);
                int fill = (int) (tw * n.fraction());
                Gui.drawRect(tx, y + 9, tx + fill, y + 12, YaUi.ACCENT);
                YaUi.roundBox(tx + fill - 3, y + 5, tx + fill + 3, y + 15, 3, YaUi.ACCENT, 0xFFFFFFFF, 1);
                String v = n.text();
                fr.drawString(v, right - fr.getStringWidth(v), y + 7, YaUi.MID);
            } else if (s instanceof Setting.Text) {
                Setting.Text t = (Setting.Text) s;
                int bw = 106;
                boolean ed = editing == t;
                YaUi.roundBox(right - bw, y + 3, right, y + 17, 5, ed ? YaUi.ACCENT : YaUi.BORDER, 0xFFFFFFFF, 1);
                String v = t.value.length() == 0 && !ed ? "click to type" : t.value;
                if (ed && (System.currentTimeMillis() / 500) % 2 == 0) v += "_";
                fr.drawString(fr.trimStringToWidth(v, bw - 8, true), right - bw + 5, y + 7, t.value.length() == 0 && !ed ? YaUi.SOFT : YaUi.DARK);
            } else {
                int bw = 106;
                YaUi.roundRect(right - bw, y + 3, right, y + 17, 5, keyEdit == s ? YaUi.ACCENT : YaUi.CHIP);
                String v;
                int tc = YaUi.DARK;
                if (s instanceof Setting.Choice) v = choiceText((Setting.Choice) s);
                else if (s instanceof Setting.Palette) {
                    Setting.Palette p = (Setting.Palette) s;
                    v = Setting.Palette.IDS[Math.max(0, Math.min(p.index, Setting.Palette.IDS.length - 1))];
                    v = Lang.has("opt." + v) ? Lang.t("opt." + v) : v;
                    Gui.drawRect(right - bw + 6, y + 7, right - bw + 12, y + 13, 0xFF000000 | (p.rgb() & 0xFFFFFF));
                } else if (s instanceof Setting.Key) {
                    v = keyEdit == s ? "press a key..." : ((Setting.Key) s).text();
                    if (keyEdit == s) tc = 0xFFFFFFFF;
                } else {
                    v = "-";
                }
                int textX = right - bw / 2 - fr.getStringWidth(v) / 2 + (s instanceof Setting.Palette ? 5 : 0);
                fr.drawString(v, textX, y + 7, tc);
            }
            y += ROW_H;
        }
        YaUi.scissorOff();
    }

    // ----------------------------------------------------------------- input

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        super.mouseClicked(mx, my, button);
        layout();
        FontRenderer fr = fontRendererObj;

        int cbx = px + pw - 28, cby = py + 9;
        if (button == 0 && mx >= cbx && mx < cbx + 18 && my >= cby && my < cby + 18) {
            click();
            mc.displayGuiScreen(null);
            return;
        }
        int fy = py + ph - 26;
        if (button == 0 && mx >= px + 14 && mx < px + 78 && my >= fy - 1 && my < fy + 15) {
            click();
            mc.displayGuiScreen(new HudEditorScreen());
            return;
        }

        if (open != null) {
            clickSettings(mx, my, button);
            return;
        }
        if (button != 0) return;

        int sx0 = px + 14;
        for (String c : cats) sx0 += fr.getStringWidth(c) + 22;
        int sbw = Math.min(120, Math.max(0, px + pw - 14 - sx0 - 4)), sbx = px + pw - 14 - sbw;
        searching = sbw >= 70 && mx >= sbx && mx < sbx + sbw && my >= py + 43 && my < py + 59;
        if (searching) return;

        int cx = px + 14;
        for (int k = 0; k < cats.size(); k++) {
            int cw = fr.getStringWidth(cats.get(k)) + 16;
            if (mx >= cx && mx < cx + cw && my >= py + 43 && my < py + 59) {
                if (catKeys.get(k) != category) {
                    category = catKeys.get(k);
                    rebuild();
                    click();
                }
                return;
            }
            cx += cw + 6;
        }

        if (mx >= gx && mx < gx + gw && my >= gy && my < gy + gh) {
            for (int i = 0; i < shown.size(); i++) {
                Module m = shown.get(i);
                int x = cardX(i), y = cardY(i);
                if (mx >= x && mx < x + cardW && my >= y && my < y + CARD_H) {
                    int bx = x + cardW - 62, by = y + CARD_H - 18;
                    if (!m.settings.isEmpty() && mx >= bx && mx < bx + 54 && my >= by && my < by + 13) {
                        gridScroll = scrollTarget;
                        open = m;
                        scroll = 0.0F;
                        scrollTarget = 0.0F;
                    } else {
                        m.toggle();
                    }
                    click();
                    return;
                }
            }
        }
    }

    private void clickSettings(int mx, int my, int button) {
        editing = null;
        keyEdit = null;
        if (button == 0 && mx >= gx && mx < gx + 52 && my >= py + 43 && my < py + 59) {
            closeSettings();
            click();
            return;
        }
        if (button == 0 && mx >= gx + gw - 26 && mx < gx + gw && my >= py + 43 && my < py + 61) {
            open.toggle();
            click();
            return;
        }
        if (my < gy || my >= gy + gh) return;
        int y = gy + 4 - (int) scroll;
        for (Row r : rows()) {
            int h = r.h();
            if (r.s != null && my >= y && my < y + h && mx >= gx && mx < gx + gw) {
                Setting s = r.s;
                int right = gx + gw - 10;
                if (s instanceof Setting.Bool) {
                    Setting.Bool b = (Setting.Bool) s;
                    b.value = !b.value;
                    open.saveConfig();
                    click();
                } else if (s instanceof Setting.Num) {
                    if (button == 0) {
                        dragging = (Setting.Num) s;
                        sliderTo(dragging, mx);
                    }
                } else if (s instanceof Setting.Text) {
                    if (mx >= right - 106) editing = (Setting.Text) s;
                } else if (mx >= right - 106) {
                    int dir = button == 1 ? -1 : 1;
                    if (s instanceof Setting.Choice) {
                        Setting.Choice c = (Setting.Choice) s;
                        c.index = (c.index + dir + c.options.length) % c.options.length;
                        open.saveConfig();
                        click();
                    } else if (s instanceof Setting.Palette) {
                        Setting.Palette p = (Setting.Palette) s;
                        int n = Setting.Palette.IDS.length;
                        p.index = (p.index + dir + n) % n;
                        open.saveConfig();
                        click();
                    } else if (s instanceof Setting.Key) {
                        keyEdit = (Setting.Key) s;
                    }
                }
                return;
            }
            y += h;
        }
    }

    private void sliderTo(Setting.Num s, int mx) {
        int tx = gx + gw - 10 - 150;
        s.setFraction((mx - tx) / 100.0F);
    }

    @Override
    protected void mouseClickMove(int mx, int my, int button, long time) {
        if (dragging != null) sliderTo(dragging, mx);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        if (dragging != null) {
            dragging = null;
            if (open != null) open.saveConfig();
        }
        super.mouseReleased(mx, my, state);
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (keyEdit != null) {
            if (key == Keyboard.KEY_ESCAPE) keyEdit = null;
            else {
                keyEdit.code = key == Keyboard.KEY_BACK ? 0 : key;
                keyEdit = null;
                if (open != null) open.saveConfig();
            }
            return;
        }
        if (editing != null) {
            if (key == Keyboard.KEY_RETURN || key == Keyboard.KEY_ESCAPE) {
                editing = null;
                if (open != null) open.saveConfig();
            } else if (key == Keyboard.KEY_BACK) {
                if (editing.value.length() > 0) editing.value = editing.value.substring(0, editing.value.length() - 1);
            } else if (ChatAllowedCharacters.isAllowedCharacter(c) && editing.value.length() < editing.maxLen) {
                editing.value += c;
            }
            return;
        }
        if (searching && open == null) {
            if (key == Keyboard.KEY_RETURN || key == Keyboard.KEY_ESCAPE) {
                searching = false;
                if (key == Keyboard.KEY_ESCAPE && query.length() > 0) {
                    query = "";
                    rebuild();
                }
            } else if (key == Keyboard.KEY_BACK) {
                if (query.length() > 0) {
                    query = query.substring(0, query.length() - 1);
                    rebuild();
                }
            } else if (key != Keyboard.KEY_RSHIFT && ChatAllowedCharacters.isAllowedCharacter(c) && query.length() < 20) {
                query += c;
                rebuild();
            }
            if (key != Keyboard.KEY_RSHIFT) return;
        }
        if (key == Keyboard.KEY_RSHIFT) {
            mc.displayGuiScreen(null);
            return;
        }
        if (key == Keyboard.KEY_ESCAPE && open != null) {
            closeSettings();
            return;
        }
        super.keyTyped(c, key);
    }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) {
            scrollTarget -= Integer.signum(d) * (open == null ? CARD_H * 0.7F : ROW_H * 2.0F);
            scrollTarget = Math.max(0, Math.min(open == null ? maxScroll() : settingsMax(), scrollTarget));
        }
    }

    private void closeSettings() {
        open = null;
        scroll = gridScroll;
        scrollTarget = gridScroll;
    }

    private List<Row> rows() {
        List<Row> r = new ArrayList<Row>();
        String lastGroup = null;
        for (Setting s : open.settings) {
            if (s instanceof Setting.Pixels) continue; // the crosshair bitmap is edited in the crosshair editor
            if (s.group != null && !s.group.equals(lastGroup)) {
                lastGroup = s.group;
                if (!"general".equals(s.group) && Lang.has("grp." + s.group)) r.add(new Row(Lang.t("grp." + s.group), null));
            }
            r.add(new Row(null, s));
        }
        return r;
    }

    private int settingsMax() {
        int h = 4;
        for (Row r : rows()) h += r.h();
        return Math.max(0, h - gh);
    }

    private void click() {
        mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation("gui.button.press"), 1.0F));
    }
}
