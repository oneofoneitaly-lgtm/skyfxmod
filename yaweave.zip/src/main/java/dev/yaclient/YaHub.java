package dev.yaclient;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

/** Small menu opened by Right Shift (same as YA MODS): MODS or COSMETICS. */
public class YaHub extends GuiScreen {

    private int px, py, pw = 230, ph = 112;
    private long openTime;

    @Override
    public void initGui() { openTime = System.currentTimeMillis(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    private boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        float o = Math.min(1.0F, (System.currentTimeMillis() - openTime) / 200.0F);
        o = 1.0F - (1.0F - o) * (1.0F - o);
        px = (width - pw) / 2;
        py = (height - ph) / 2 + (int) ((1.0F - o) * 10.0F);
        drawRect(0, 0, width, height, ((int) (o * 110.0F) << 24));
        YaUi.roundBox(px, py, px + pw, py + ph, 6, YaUi.BORDER, YaUi.BG, 1);
        FontRenderer fr = fontRendererObj;
        fr.drawString("YA CLIENT", px + 14, py + 12, YaUi.DARK);
        String hint = "Choose a menu";
        fr.drawString(hint, px + pw - 14 - fr.getStringWidth(hint), py + 12, YaUi.SOFT);
        card(mx, my, px + 14, py + 34, "MODS", "All the modules");
        card(mx, my, px + 14 + (pw - 28) / 2 + 4, py + 34, "COSMETICS", "Your cosmetics");
    }

    private void card(int mx, int my, int x, int y, String t, String sub) {
        int w = (pw - 28) / 2 - 4, h = 58;
        boolean hv = in(mx, my, x, y, w, h);
        YaUi.roundBox(x, y, x + w, y + h, 5, hv ? YaUi.ACCENT : YaUi.BORDER, hv ? YaUi.CARD_HOVER : YaUi.CARD, 1);
        FontRenderer fr = fontRendererObj;
        fr.drawString(t, x + (w - fr.getStringWidth(t)) / 2, y + 18, YaUi.DARK);
        fr.drawString(sub, x + (w - fr.getStringWidth(sub)) / 2, y + 34, YaUi.SOFT);
    }

    @Override
    protected void mouseClicked(int mx, int my, int button) throws IOException {
        super.mouseClicked(mx, my, button);
        if (button != 0) return;
        int w = (pw - 28) / 2 - 4;
        if (in(mx, my, px + 14, py + 34, w, 58)) mc.displayGuiScreen(new YaModMenu());
        else if (in(mx, my, px + 14 + (pw - 28) / 2 + 4, py + 34, w, 58)) mc.displayGuiScreen(new MenuScreen(4));
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE || key == Keyboard.KEY_RSHIFT) mc.displayGuiScreen(null);
    }
}
