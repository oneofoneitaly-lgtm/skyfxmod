package dev.yaclient.ya;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * The world renderer, replaced by a subclass (state copied over) so the YA MODS modules can do what Forge events
 * did on the Forge version: zoom (FOV), free look, camera height (smooth shift), hide fire, hide the vanilla block
 * outline and "no FOV effects". Nothing about the real position or movement is changed.
 */
public final class YaRenderer extends EntityRenderer {

    private static boolean failed;
    private boolean inWorld, hideSel;

    private YaRenderer(Minecraft mc) {
        super(mc, mc.getResourceManager());
    }

    static void install() {
        Minecraft mc = Minecraft.getMinecraft();
        if (failed || mc.entityRenderer == null || mc.entityRenderer instanceof YaRenderer) return;
        try {
            EntityRenderer old = mc.entityRenderer;
            YaRenderer neu = new YaRenderer(mc);
            for (Class<?> c = EntityRenderer.class; c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    if (Modifier.isStatic(f.getModifiers())) continue;
                    f.setAccessible(true);
                    f.set(neu, f.get(old));
                }
            }
            mc.entityRenderer = neu;
        } catch (Throwable t) {
            failed = true;      // never break the game because of a camera detail
            System.out.println("[YA MODS] renderer hook not installed: " + t);
        }
    }

    private static boolean on(String id) {
        Module m = Mods.byId(id);
        return m != null && m.enabled;
    }

    @Override
    public void updateCameraAndRender(float partialTicks, long nano) {
        Minecraft mc = Minecraft.getMinecraft();
        Mods.Zoom z = Mods.ZOOM;
        float fov = mc.gameSettings.fovSetting;
        boolean zoomed = z.enabled && z.anim > 0.0F;
        EntityPlayer p = mc.thePlayer;
        boolean fire = p != null && on("nofire") && Boolean.FALSE.equals(Shim.immuneToFire(p));
        boolean swapped = false;
        try {
            if (Mods.FREELOOK.enabled) {
                Mods.FREELOOK.renderTickStart();
                swapped = true;
            }
        } catch (Throwable ignored) {
        }
        try {
            if (zoomed) mc.gameSettings.fovSetting = fov * z.fovMultiplier();
            if (fire) Shim.setImmuneToFire(p, true);
            super.updateCameraAndRender(partialTicks, nano);
        } finally {
            if (zoomed) mc.gameSettings.fovSetting = fov;
            if (fire) Shim.setImmuneToFire(p, false);
            try {
                Mods.FREELOOK.renderTickEnd(); // always, so the real rotation comes back even if the module was just switched off
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    public void updateRenderer() {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer p = mc.thePlayer;
        float walk = 0;
        boolean nofov = false;
        try {
            if (p != null && on("nofoveffects")) {
                walk = p.capabilities.getWalkSpeed();
                p.capabilities.setPlayerWalkSpeed((float) p.getEntityAttribute(SharedMonsterAttributes.movementSpeed).getAttributeValue());
                nofov = true;
            }
        } catch (Throwable ignored) {
        }
        try {
            super.updateRenderer();
        } finally {
            if (nofov) p.capabilities.setPlayerWalkSpeed(walk);
        }
    }

    @Override
    public void getMouseOver(float partialTicks) {
        super.getMouseOver(partialTicks);
        if (inWorld && hideSel) {
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK) {
                Bridge.mop = mc.objectMouseOver;
                mc.objectMouseOver = null;   // the vanilla outline is not drawn; our module draws its own
            }
        }
    }

    @Override
    public void renderWorld(float partialTicks, long nano) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity v = mc.getRenderViewEntity();
        double d = 0.0D;
        for (Module m : Mods.H_EYE) {
            if (m.enabled && v == mc.thePlayer) {
                try {
                    d += m.eyeOffset();
                } catch (Throwable ignored) {
                }
            }
        }
        hideSel = false;
        for (Module m : Mods.H_BLOCK) {
            if (m.enabled) {
                hideSel = true;
                break;
            }
        }
        Bridge.mop = null;
        inWorld = true;
        if (d != 0.0D && v != null) {
            v.posY += d;
            v.prevPosY += d;
            v.lastTickPosY += d;
        }
        try {
            super.renderWorld(partialTicks, nano);
        } finally {
            inWorld = false;
            if (d != 0.0D && v != null) {
                v.posY -= d;
                v.prevPosY -= d;
                v.lastTickPosY -= d;
            }
            if (Bridge.mop != null) {
                mc.objectMouseOver = Bridge.mop;   // clicks need the real target back
                Bridge.mop = null;
            }
        }
    }
}
