package dev.yaclient.ya;

import org.lwjgl.input.Keyboard;

/** A fixed key that is polled (no Forge key bindings on Weave). */
public final class KeyBind {
    private final int code;
    private boolean was;

    KeyBind(int code) {
        this.code = code;
    }

    public int getKeyCode() {
        return code;
    }

    public boolean isKeyDown() {
        return code > 0 && Keyboard.isKeyDown(code);
    }

    /** True once per press. */
    public boolean isPressed() {
        boolean d = isKeyDown();
        boolean r = d && !was;
        was = d;
        return r;
    }
}
