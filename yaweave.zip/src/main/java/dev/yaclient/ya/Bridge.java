package dev.yaclient.ya;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MovingObjectPosition;
import net.weavemc.api.event.EventBus;
import net.weavemc.api.event.RenderGameOverlayEvent;
import net.weavemc.api.event.TickEvent;
import net.weavemc.api.event.WorldEvent;

import java.io.File;
import java.lang.reflect.Method;
import java.util.function.Consumer;

/**
 * Connects the YA MODS modules (the same ones as the Forge mod) to the Weave events.
 * Events that Weave does not have (FOV, crosshair, tab list, chat box, block outline, fire, camera height) are done
 * through {@link YaRenderer} and {@link dev.yaclient.YaIngame}.
 */
public final class Bridge {

    private static Minecraft mc;
    private static volatile boolean booted;
    private static int saveTimer;
    private static boolean capeDone;
    private static boolean mouseEvents;      // true once Weave delivered a mouse event (then polling is not needed)
    private static boolean leftWas, rightWas;
    private static int slot = -1;

    /** The block you look at, kept while the vanilla outline is hidden for the frame. */
    static MovingObjectPosition mop;

    private Bridge() {
    }

    /** Called while the client loads (Minecraft does not exist yet): only subscribes; the modules start on the first tick. */
    public static void init() {
        EventBus.subscribe(TickEvent.Pre.class, e -> {
            if (!booted) boot();
        });
        EventBus.subscribe(TickEvent.Post.class, e -> {
            if (booted) guard(Bridge::tick);
        });
        EventBus.subscribe(RenderGameOverlayEvent.Post.class, e -> {
            if (booted) guard(Bridge::overlay);
        });
        EventBus.subscribe(WorldEvent.Unload.class, e -> {
            if (booted) guard(Mods::save);
        });
        on("net.weavemc.api.event.RenderWorldEvent", e -> {
            if (booted) world(num(e, "getPartialTicks", 1.0F));
        });
        on("net.weavemc.api.event.RenderHandEvent", e -> {
            if (!booted) return;
            float pt = num(e, "getPartialTicks", 1.0F);
            for (Module m : Mods.H_HAND) if (m.enabled) guard(() -> m.renderHand(pt));
        });
        on("net.weavemc.api.event.MouseEvent", e -> {
            if (booted) mouse(e);
        });
        on("net.weavemc.api.event.RenderLivingEvent$Pre", e -> {
            if (booted) living(e);
        });
        on("net.weavemc.api.event.ChatEvent$Received", e -> {
            if (booted) chat(e);
        });
    }

    private static synchronized void boot() {
        if (booted) return;
        try {
            mc = Minecraft.getMinecraft();
            if (mc == null) return;
            Q.mc = mc;
            File dir = new File(System.getProperty("user.home"), ".yaclient");
            dir.mkdirs();
            Mods.init(dir);
            booted = true;
            System.out.println("[YA MODS] " + Mods.ALL.size() + " modules loaded");
        } catch (Throwable t) {
            booted = true;   // do not retry every tick
            System.out.println("[YA MODS] start failed: " + t);
            t.printStackTrace();
        }
    }

    // ------------------------------------------------------------ helpers

    private static void guard(Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            System.out.println("[YA MODS] " + t);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void on(String cls, final Consumer<Object> c) {
        try {
            Class k = Class.forName(cls);
            EventBus.subscribe(k, (Consumer) new Consumer<Object>() {
                @Override
                public void accept(Object e) {
                    try {
                        c.accept(e);
                    } catch (Throwable t) {
                        System.out.println("[YA MODS] " + cls + ": " + t);
                    }
                }
            });
        } catch (Throwable t) {
            System.out.println("[YA MODS] event not found: " + cls);
        }
    }

    private static Object get(Object o, String name) {
        try {
            Method m = o.getClass().getMethod(name);
            return m.invoke(o);
        } catch (Throwable t) {
            return null;
        }
    }

    private static float num(Object o, String name, float def) {
        Object v = get(o, name);
        return v instanceof Number ? ((Number) v).floatValue() : def;
    }

    // ------------------------------------------------------------ tick

    private static void tick() {
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (!capeDone) {
            capeDone = true;
            ClientCape.installAll();
        }
        if (!(mc.entityRenderer instanceof YaRenderer)) YaRenderer.install();
        if (++saveTimer >= 600) {
            saveTimer = 0;
            Mods.save();
        }
        if (!mouseEvents) pollMouse();
        Q.tick(mc.thePlayer);
        YaNet.tick();
        scrollZoom();
        for (Module m : Mods.H_TICK) {
            if (m.enabled) guard(m::onTick);
        }
        if (!Mods.ZOOM.enabled) Mods.ZOOM.onDisable();
    }

    /** The mouse wheel moves the hotbar: while zooming turn it into zoom steps and put the slot back. */
    private static void scrollZoom() {
        Mods.Zoom z = Mods.ZOOM;
        int cur = mc.thePlayer.inventory.currentItem;
        if (z.enabled && z.zooming && z.scroll.b && slot >= 0 && cur != slot) {
            int d = ((cur - slot) % 9 + 9) % 9;
            if (d > 4) d -= 9;                       // negative = wheel up = zoom in
            z.amount.setFraction(z.amount.fraction() + (d < 0 ? 1 : -1) * Math.min(3, Math.abs(d)) * 0.06F);
            mc.thePlayer.inventory.currentItem = slot;
            cur = slot;
        }
        slot = cur;
    }

    // ------------------------------------------------------------ HUD

    private static ScaledResolution sr;
    private static int srW, srH, srScale;

    private static void overlay() {
        if (mc.thePlayer == null || mc.gameSettings.hideGUI) return;
        if (mc.currentScreen instanceof HudEditor) return; // the editor draws the HUD itself
        if (sr == null || srW != mc.displayWidth || srH != mc.displayHeight || srScale != mc.gameSettings.guiScale) {
            sr = new ScaledResolution(mc);
            srW = mc.displayWidth;
            srH = mc.displayHeight;
            srScale = mc.gameSettings.guiScale;
        }
        Hud.renderAll(sr.getScaledWidth(), sr.getScaledHeight(), false, mc.gameSettings.showDebugInfo);
    }

    // ------------------------------------------------------------ world

    private static void world(float pt) {
        if (mc.thePlayer == null) return;
        for (Module m : Mods.H_WORLD) if (m.enabled) guard(() -> m.renderWorld(pt));
        MovingObjectPosition t = mop;
        if (t != null && t.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            Shim.BlockHit e = new Shim.BlockHit();
            e.target = t;
            e.player = mc.thePlayer;
            e.partialTicks = pt;
            for (Module m : Mods.H_BLOCK) {
                if (m.enabled) {
                    try {
                        if (m.drawBlock(e)) break;
                    } catch (Throwable ex) {
                        System.out.println("[YA MODS] " + ex);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ mouse / attack

    private static void mouse(Object e) {
        mouseEvents = true;
        Object b = get(e, "getButton"), s = get(e, "getButtonState");
        if (!(b instanceof Number) || !(s instanceof Boolean)) return;
        if (mc.currentScreen != null || mc.thePlayer == null) return;
        if (((Boolean) s) && ((Number) b).intValue() == 0) leftClick();
        if (((Boolean) s) && ((Number) b).intValue() == 1) Mods.click(false);
    }

    private static void pollMouse() {
        boolean l = org.lwjgl.input.Mouse.isButtonDown(0) && mc.currentScreen == null;
        boolean r = org.lwjgl.input.Mouse.isButtonDown(1) && mc.currentScreen == null;
        if (l && !leftWas) leftClick();
        if (r && !rightWas) Mods.click(false);
        leftWas = l;
        rightWas = r;
    }

    private static void leftClick() {
        Mods.click(true);
        for (Module m : Mods.H_CLICK) if (m.enabled) guard(m::leftClick);
        MovingObjectPosition o = mc.objectMouseOver;
        if (o != null && o.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY && o.entityHit instanceof EntityLivingBase) {
            attack(o.entityHit);
        }
    }

    private static void attack(net.minecraft.entity.Entity target) {
        Q.hit(target);
        for (Module m : Mods.H_ATTACK) if (m.enabled) guard(() -> m.attacked(target));
        Module sp = Mods.byId("hitsparks");
        if (sp != null && sp.enabled) ((Fx.HitSparks) sp).spark(target);
        Mods.lastReach = mc.thePlayer.getDistanceToEntity(target);
        MovingObjectPosition o = mc.objectMouseOver;
        if (o != null && o.hitVec != null && o.entityHit == target) {
            Mods.lastReach = (float) mc.thePlayer.getPositionEyes(1.0F).distanceTo(o.hitVec);
        }
    }

    // ------------------------------------------------------------ name tags / chat

    private static void living(Object e) {
        Module n = Mods.byId("nicktag");
        if (n == null || !n.enabled) return;
        Object ent = get(e, "getEntity");
        if (!(ent instanceof EntityLivingBase)) return;
        ((NickTag) n).label((EntityLivingBase) ent, num(e, "getX", 0), num(e, "getY", 0), num(e, "getZ", 0));
    }

    private static void chat(Object e) {
        if (Mods.H_CHAT.length == 0) return;
        Object msg = get(e, "getMessage");
        if (!(msg instanceof net.minecraft.util.IChatComponent)) return;
        Shim.Chat c = new Shim.Chat();
        c.message = (net.minecraft.util.IChatComponent) msg;
        for (Module m : Mods.H_CHAT) if (m.enabled) guard(() -> m.chat(c));
        if (c.message != msg) {
            try {
                e.getClass().getMethod("setMessage", net.minecraft.util.IChatComponent.class).invoke(e, c.message);
            } catch (Throwable ignored) {
            }
        }
    }
}
