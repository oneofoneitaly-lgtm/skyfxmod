package dev.yaclient.ya;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MovingObjectPosition;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/** Small event holders (same field names the Forge version used) and reflection helpers. */
public final class Shim {

    private Shim() {
    }

    /** The block you look at (outline hook). */
    public static class BlockHit {
        public MovingObjectPosition target;
        public EntityPlayer player;
        public float partialTicks;
    }

    /** Camera set-up (kept so the module API stays the same). */
    public static class Camera {
        public Entity entity;
        public float pitch, yaw, roll;
    }

    /** A chat message that is about to be shown. */
    public static class Chat {
        public IChatComponent message;
        public int type;
    }

    /** Value of the first instance field of the given type declared by 'owner' (names differ between mappings, types do not). */
    @SuppressWarnings("unchecked")
    public static <T> T firstFieldOfType(Class<?> owner, Object inst, Class<T> type) {
        try {
            for (Field f : owner.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !type.isAssignableFrom(f.getType())) continue;
                f.setAccessible(true);
                return (T) f.get(inst);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Every player renderer (Steve and Alex model); the render manager has no public getter for them. */
    public static java.util.Set<net.minecraft.client.renderer.entity.RenderPlayer> renderPlayers() {
        java.util.Set<net.minecraft.client.renderer.entity.RenderPlayer> out = new java.util.LinkedHashSet<net.minecraft.client.renderer.entity.RenderPlayer>();
        try {
            Object rm = net.minecraft.client.Minecraft.getMinecraft().getRenderManager();
            for (Field f : rm.getClass().getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                f.setAccessible(true);
                Object v = f.get(rm);
                if (v instanceof java.util.Map) {
                    for (Object o : ((java.util.Map<?, ?>) v).values()) if (o instanceof net.minecraft.client.renderer.entity.RenderPlayer) out.add((net.minecraft.client.renderer.entity.RenderPlayer) o);
                } else if (v instanceof net.minecraft.client.renderer.entity.RenderPlayer) {
                    out.add((net.minecraft.client.renderer.entity.RenderPlayer) v);
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static Field immune;
    private static boolean immuneTried;

    /** The protected "immune to fire" flag of an entity (null when it cannot be reached). */
    public static Boolean immuneToFire(Entity e) {
        try {
            Field f = immuneField();
            return f == null ? null : f.getBoolean(e);
        } catch (Throwable t) {
            return null;
        }
    }

    public static void setImmuneToFire(Entity e, boolean v) {
        try {
            Field f = immuneField();
            if (f != null) f.setBoolean(e, v);
        } catch (Throwable ignored) {
        }
    }

    private static Field immuneField() {
        if (!immuneTried) {
            immuneTried = true;
            try {
                immune = Entity.class.getDeclaredField("isImmuneToFire");
                immune.setAccessible(true);
            } catch (Throwable t) {
                immune = null;
            }
        }
        return immune;
    }
}
