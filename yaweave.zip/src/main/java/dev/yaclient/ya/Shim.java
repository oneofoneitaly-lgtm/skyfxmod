package dev.yaclient.ya;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MovingObjectPosition;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/** Small event holders (same field names the Forge version used) and reflection helpers. */
public final class Shim {

    private Shim() {
    }

    /** The block you look at (outline hook). */
    public static class BlockHit {
        public MovingObjectPosition target;
        public EntityPlayer player;
        public float partialTicks;
    }

    /** Camera set-up (kept so the module API stays the same). */
    public static class Camera {
        public Entity entity;
        public float pitch, yaw, roll;
    }

    /** A chat message that is about to be shown. */
    public static class Chat {
        public IChatComponent message;
        public int type;
    }

    /** Value of the first instance field of the given type declared by 'owner' (names differ between mappings, types do not). */
    @SuppressWarnings("unchecked")
    public static <T> T firstFieldOfType(Class<?> owner, Object inst, Class<T> type) {
        try {
            for (Field f : owner.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || !type.isAssignableFrom(f.getType())) continue;
                f.setAccessible(true);
                return (T) f.get(inst);
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}
