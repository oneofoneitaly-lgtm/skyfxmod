package dev.yaclient.ya;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.util.ResourceLocation;

import java.awt.image.BufferedImage;
import java.io.InputStream;

/** Loads a PNG from inside the mod jar as a texture (jar resources are not part of Minecraft's resource manager here). */
final class Tex {

    private Tex() {
    }

    static ResourceLocation load(String name, String path) {
        try {
            InputStream in = Tex.class.getResourceAsStream(path);
            if (in == null) {
                ClassLoader cl = Thread.currentThread().getContextClassLoader();
                if (cl != null) in = cl.getResourceAsStream(path.substring(1));
            }
            if (in == null) return null;
            BufferedImage img = javax.imageio.ImageIO.read(in);
            in.close();
            return Minecraft.getMinecraft().getTextureManager().getDynamicTextureLocation(name, new DynamicTexture(img));
        } catch (Throwable t) {
            return null;
        }
    }
}
