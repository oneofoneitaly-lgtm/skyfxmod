package dev.yaclient.ya;

import net.minecraft.client.gui.GuiScreen;

/** Public entry points of the YA MODS port for the rest of the client. */
public final class Api {

    private Api() {
    }

    public static GuiScreen modMenu() {
        return new ModMenu();
    }

    public static GuiScreen hudEditor() {
        return new HudEditor();
    }

    public static boolean hideCrosshair() {
        Module c = Mods.byId("crosshair");
        return c != null && c.enabled;
    }

    public static boolean hideTab() {
        Module t = Mods.byId("tablist");
        return t != null && t.enabled;
    }

    public static boolean hideChat() {
        Module c = Mods.byId("chatbox");
        return c != null && c.enabled && ((Panels.ChatBox) c).ready();
    }
}
