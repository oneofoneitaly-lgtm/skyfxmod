package dev.yaclient.ya;

import org.lwjgl.input.Keyboard;

/** Constants and keys of YA MODS. */
public final class YAMods {
    public static final String NAME = "YA MODS";
    public static final String AUTHOR = "@Adryh01";

    public static final KeyBind menuKey = new KeyBind(Keyboard.KEY_RSHIFT);
    public static final KeyBind zoomKey = new KeyBind(Keyboard.KEY_C);
    public static final KeyBind freelookKey = new KeyBind(Keyboard.KEY_LMENU);

    private YAMods() {
    }
}
