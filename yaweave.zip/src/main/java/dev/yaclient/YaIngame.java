package dev.yaclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreObjective;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * In-game GUI that hides, when the matching YA MODS module is on, the vanilla crosshair, the vanilla chat box and the
 * vanilla tab list (the modules draw their own). No Mixin: the crosshair is the 16x16 icon at u=0, v=0 centered on
 * the screen, and the chat / tab renderers are swapped for subclasses that skip drawing.
 */
public class YaIngame extends GuiIngame {
    private final Minecraft game;

    public YaIngame(Minecraft mc) {
        super(mc);
        this.game = mc;
        swap(GuiNewChat.class, new GuiNewChat(mc) {
            @Override
            public void drawChat(int counter) {
                if (!dev.yaclient.ya.Api.hideChat()) super.drawChat(counter);
            }
        });
        swap(GuiPlayerTabOverlay.class, new GuiPlayerTabOverlay(mc, this) {
            @Override
            public void renderPlayerlist(int width, Scoreboard sb, ScoreObjective obj) {
                if (!dev.yaclient.ya.Api.hideTab()) super.renderPlayerlist(width, sb, obj);
            }
        });
    }

    private void swap(Class<?> type, Object value) {
        try {
            for (Field f : GuiIngame.class.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || f.getType() != type) continue;
                f.setAccessible(true);
                f.set(this, value);
                return;
            }
        } catch (Throwable t) {
            System.out.println("[YA CLIENT] could not swap " + type.getSimpleName() + ": " + t);
        }
    }

    @Override
    public void drawTexturedModalRect(int x, int y, int u, int v, int w, int h) {
        if (w == 16 && h == 16 && u == 0 && v == 0 && dev.yaclient.ya.Api.hideCrosshair()) {
            ScaledResolution sr = new ScaledResolution(game);
            if (x == sr.getScaledWidth() / 2 - 7 && y == sr.getScaledHeight() / 2 - 7) return;
        }
        super.drawTexturedModalRect(x, y, u, v, w, h);
    }

    /** Swaps the game's GUI for this one (once, at the main menu so no chat history is lost). */
    public static void install() {
        Minecraft mc = Minecraft.getMinecraft();
        try {
            if (mc.ingameGUI != null && !(mc.ingameGUI instanceof YaIngame)) mc.ingameGUI = new YaIngame(mc);
        } catch (Throwable t) {
            System.out.println("[YA CLIENT] in-game GUI hook not installed: " + t);
        }
    }
}
