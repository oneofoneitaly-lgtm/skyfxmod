package dev.yaclient.ymenu;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

/** YA MENU screens (white style) for the Weave client: title, pause, singleplayer, multiplayer, options. */
public final class YAMenu {

    private YAMenu() {}

    public static GuiScreen home() { return new YAMainMenuClassic(); }

    public static GuiScreen pause() { return new YAPause(); }

    public static GuiScreen multiplayer(GuiScreen parent) { return new YAMultiplayer(parent == null ? home() : parent); }

    public static GuiScreen singleplayer(GuiScreen parent) { return new YASingleplayer(parent == null ? home() : parent); }

    /** White loading screen: the logo and a black bar that runs back and forth. */
    public static void loading(int w, int h) {
        Gui.drawRect(0, 0, w, h, 0xFFFFFFFF);
        UI.logo(w / 2 - 40, h / 2 - 70, 80);
        int bw = 160, x = w / 2 - bw / 2, y = h / 2 + 30;
        Gui.drawRect(x - 1, y - 1, x + bw + 1, y + 7, 0xFF111111);
        Gui.drawRect(x, y, x + bw, y + 6, 0xFFFFFFFF);
        float t = (System.currentTimeMillis() % 1400L) / 1400.0F;
        int seg = 56, px = x + (int) ((bw + seg) * t) - seg;
        Gui.drawRect(Math.max(x, px), y, Math.min(x + bw, px + seg), y + 6, 0xFF111111);
    }
}
